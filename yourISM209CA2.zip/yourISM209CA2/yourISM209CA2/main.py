from flask import Flask, render_template

app = Flask(__name__)  # create a flask app named app


@app.route("/")
def home():
    return '''My name is Odujoko Temiloluwa. This is my CA2 work.
    My Github URL is https://github.com/temiloluwa24'''


@app.route("/hello")
def hello():
    return render_template('home.html', title="Hello")


class RegistrationForm(Form):
    firstname = Textfield('firstname', [validators.Length(min(10), max(20))])
    surname = Textfield('surname', [validators.Length(min(10), max(20))])
    dateofbirth = Textfield('dateofbirth', [validators.Length(min(10), max(20))])
    residentialaddress = Textfield('residentialaddress', [validators.Length(min(20), max(30))])

@app.route("/registration")
def registration():
    return render_template('registration.html', title= 'REGISTER', information= 'Click here to register')

@app.route('register', methods={"GET", "POST"})
def register_page():
   try:
       = RegistrationForm(request.form)




if __name__ == "__main__":
    app.run(port=5099)

